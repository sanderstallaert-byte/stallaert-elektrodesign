import React from 'react';
import StallaertWebsite from './StallaertWebsite.jsx';

export default function App() {
  return <StallaertWebsite />;
}
