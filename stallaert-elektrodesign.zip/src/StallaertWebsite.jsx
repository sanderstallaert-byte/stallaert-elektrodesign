import React from 'react';

export default function StallaertWebsite() {
  return (
    <div style={{padding: '40px', fontFamily: 'Arial'}}>
      <h1>Stallaert ElektroDesign</h1>
      <p>De volledige websitecode kan hier ingevuld worden.</p>
    </div>
  );
}
